﻿using System;
using System.IO;
using System.Net;
using System.Text;
using System.Drawing;
using System.Threading;
using System.Diagnostics;
using System.Windows.Forms;
using Microsoft.VisualBasic;
using System.Threading.Tasks;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using Microsoft.VisualBasic.CompilerServices;
using Microsoft.Win32;

namespace AutoClicker.Main
{
    public partial class Main : Form
    {
        public static int Seed;

        private WebClient Client = new WebClient();

        public static bool IsOpen = false;

        public static ThreadLocal<Random> ThreadLock = new ThreadLocal<Random>(() => new Random(Interlocked.Decrement(ref Seed)));

        public static System.Security.Cryptography.RNGCryptoServiceProvider Prov = new System.Security.Cryptography.RNGCryptoServiceProvider();

        public static string MachineHWID = HWID.GetMachineGuid();

        public static Random Instance { get { return ThreadLock.Value; } }

        public static int GetRandom() { return Guid.NewGuid().GetHashCode(); }

        public static string PrefetchPath = @"C:\Windows\prefetch";
        public static bool ShouldClick = false;

        public static string FingerPrint = HWID.GetMachineGuid().ToUpper();

        [DllImport("user32.dll")]
        public static extern int SendMessage(IntPtr hWnd, int Msg, int wParam, int lParam);

        [DllImport("user32.dll")]
        public static extern bool ReleaseCapture();

        [DllImport("user32.dll")]
        static extern IntPtr GetForegroundWindow();

        [DllImport("user32.dll")]
        static extern int GetWindowText(IntPtr HWND, StringBuilder Text, int Count);

        public string GetActiveWindow()
        {
            StringBuilder Caption = new StringBuilder(256);

            IntPtr HWND = GetForegroundWindow();

            GetWindowText(HWND, Caption, Caption.Capacity);

            return Caption.ToString();
        }

        private Dictionary<string, Keys> Hotkeys;

        public const int HT_CAPTION = 0x2;
        public const int WM_NCLBUTTONDOWN = 0xA1;

        [DllImport("user32.dll")]
        private static extern short GetAsyncKeyState(Keys Key);

        [DllImport("Gdi32.dll", EntryPoint = "CreateRoundRectRgn")]

        private static extern IntPtr CreateRoundRectRgn
        (
            int nLeftRect,     // X-coordinate of Upper-left Corner
            int nTopRect,      // Y-coordinate of Upper-left Corner
            int nRightRect,    // X-coordinate of Lower-right Corner
            int nBottomRect,   // Y-coordinate of lower-right Corner
            int nWidthEllipse, // Height of Ellipse
            int nHeightEllipse // Width of Ellipse
        );

        public Main()
        {

            InitializeComponent();

            Hide();
            ShowInTaskbar = false;
            Visible = false;

            Text = Title(Instance.Next(32, 66)); // Sets The Text of The Form to Random Letters and Numbers

            Hotkeys = new Dictionary<string, Keys>()
            {
                { "None", (Keys)Conversions.ToInteger(null) },
                { "A", Keys.A },
                { "B", Keys.B },
                { "C", Keys.C },
                { "D", Keys.D },
                { "E", Keys.E },
                { "F", Keys.F },
                { "G", Keys.G },
                { "H", Keys.H },
                { "I", Keys.I },
                { "J", Keys.J },
                { "K", Keys.K },
                { "L", Keys.L },
                { "M", Keys.M },
                { "N", Keys.N },
                { "O", Keys.O },
                { "P", Keys.P },
                { "Q", Keys.Q },
                { "R", Keys.R },
                { "S", Keys.S },
                { "T", Keys.T },
                { "U", Keys.U },
                { "V", Keys.V },
                { "W", Keys.W },
                { "X", Keys.X },
                { "Y", Keys.Y },
                { "Z", Keys.Z },
                { "1", Keys.D1 },
                { "2", Keys.D2 },
                { "3", Keys.D3 },
                { "4", Keys.D4 },
                { "5", Keys.D5 },
                { "6", Keys.D6 },
                { "7", Keys.D7 },
                { "8", Keys.D8 },
                { "9", Keys.D9 },
                { "MB1", Keys.LButton },
                { "MB2", Keys.RButton },
                { "MB3", Keys.MButton },
                { "MB4", Keys.XButton1 },
                { "MB5", Keys.XButton2 },
                { "F1", Keys.F1 },
                { "F2", Keys.F2 },
                { "F3", Keys.F3 },
                { "F4", Keys.F4 },
                { "F5", Keys.F5 },
                { "F6", Keys.F6 },
                { "F7", Keys.F7 },
                { "F8", Keys.F8 },
                { "F9", Keys.F9 },
                { "F10", Keys.F10 },
                { "F11", Keys.F11 },
                { "F12", Keys.F12 }
            };
        }

        public static string Title(int length)
        {
            VBMath.Randomize(); // Randomizes

            string str = null;
            string str0 = null;

            str = string.Concat(str, "abcdefghijklmnopqrstuvwxyz"); // Lowercase Letters
            str = string.Concat(str, "ABCDEFGHIJKLMNOPQRSTUVWXYZ"); // Uppercase Letters
            str = string.Concat(str, "0123456789"); // Numbers

            for (int i = 0; i < length; i = checked(i + 1))
            {
                str0 = string.Concat(str0, Conversions.ToString(str[Instance.Next(0, str.Length)]));
            }

            return str0; // Returns
        }

        private void MainPanel_Paint(object Sender, PaintEventArgs E)
        {
            ControlPaint.DrawBorder(E.Graphics, MainPanel.ClientRectangle,
                                    Color.FromArgb(60, 60, 60), ButtonBorderStyle.Solid);  // Changes Mainpanel Outline Color to Gray
        }

        private void CloseLabel_MouseEnter(object sender, EventArgs e)
        {
            CloseLabel.ForeColor = Color.Gray; // Changes Color to Gray
        }

        private void CloseLabel_MouseLeave(object sender, EventArgs e)
        {
            CloseLabel.ForeColor = Color.FromArgb(224, 224, 224); // Changes Color to White
        }

        private void MinimizeLabel_MouseEnter(object sender, EventArgs e)
        {
            MinimizeLabel.ForeColor = Color.Gray; // Changes Color to Gray
        }

        private void MinimizeLabel_MouseLeave(object sender, EventArgs e)
        {
            MinimizeLabel.ForeColor = Color.FromArgb(224, 224, 224); // Changes Color to White
        }

        private void MinimizeLabel_Click(object sender, EventArgs e)
        {
            WindowState = FormWindowState.Minimized; // Minimizes The Form
        }

        private void CloseLabel_Click(object sender, EventArgs e)
        {
            Close(); // Closes The Form
        }

        private void Main_Load(object sender, EventArgs e)
        {
            Region = Region.FromHrgn(CreateRoundRectRgn(0, 0, Width, Height, 20, 20)); // Rounds the Form

            //          IsOpen = true;




            try
            {
                string List = Client.DownloadString("https://pastebin.com/raw/DmkczALW");
                if (List == null)
                {
                    return;
                }
                if (Client == null)
                {
                    return;
                }

                if (List == null)
                {
                    return;
                }
                if (Client == null)
                {
                    return;
                }
                if (List.Contains
                    (FingerPrint))
                {
                    Show();
                    ShowInTaskbar = true;
                    Visible = true;

                    if (Properties.Settings.Default.Load == true)
                    {
                        //              Properties.Settings.Default.OnStart = true;
                        Properties.Settings.Default.Save();
                        LoadSettings();
                    }
                }
                else
                {
                }
            }
            catch
            {
                ProcessStartInfo Info = new ProcessStartInfo();

                Info.Arguments = "/C choice /C Y /N /D Y /T 3 & Del " + Application.ExecutablePath;

                Info.WindowStyle = ProcessWindowStyle.Hidden;

                Info.CreateNoWindow = false;

                Info.FileName = "cmd.exe";

                Process.Start(Info);

                Application.Exit();
                Application.ExitThread();
            }
        }

        private void ValueHandler_Tick(object sender, EventArgs e)
        {
            // Min Value Handler

            MinCPS.Text = MinimumCPS.Value.ToString();

            // Max Value Handler

            MaxCPS.Text = MaximumCPS.Value.ToString();

            // Min & Max Value Handler

            if (MinimumCPS.Value > MaximumCPS.Value)
            {
                MaximumCPS.Value = MinimumCPS.Value;

                if (MaximumCPS.Value == 21)
                {
                    MinimumCPS.Value = 18;
                    MaximumCPS.Value = 19;
                }
            }

            // Minimum Hider

            if (MinimumCPS.Value == 1)
            {
                MinValueHider.Location = new Point(11, 47);
            }
            else if (MinimumCPS.Value == 2)
            {
                MinValueHider.Location = new Point(19, 47);
            }
            else if (MinimumCPS.Value == 3)
            {
                MinValueHider.Location = new Point(32, 47);
            }
            else if (MinimumCPS.Value == 4)
            {
                MinValueHider.Location = new Point(47, 47);
            }
            else if (MinimumCPS.Value == 5)
            {
                MinValueHider.Location = new Point(62, 47);
            }
            else if (MinimumCPS.Value == 6)
            {
                MinValueHider.Location = new Point(78, 47);
            }
            else if (MinimumCPS.Value == 7)
            {
                MinValueHider.Location = new Point(89, 47);
            }
            else if (MinimumCPS.Value == 8)
            {
                MinValueHider.Location = new Point(104, 47);
            }
            else if (MinimumCPS.Value == 9)
            {
                MinValueHider.Location = new Point(118, 47);
            }
            else if (MinimumCPS.Value == 10)
            {
                MinValueHider.Location = new Point(134, 47);
            }
            else if (MinimumCPS.Value == 11)
            {
                MinValueHider.Location = new Point(156, 47);
            }
            else if (MinimumCPS.Value == 12)
            {
                MinValueHider.Location = new Point(169, 47);
            }
            else if (MinimumCPS.Value == 13)
            {
                MinValueHider.Location = new Point(180, 47);
            }
            else if (MinimumCPS.Value == 14)
            {
                MinValueHider.Location = new Point(195, 47);
            }
            else if (MinimumCPS.Value == 15)
            {
                MinValueHider.Location = new Point(209, 47);
            }
            else if (MinimumCPS.Value == 16)
            {
                MinValueHider.Location = new Point(236, 47);
            }
            else if (MinimumCPS.Value == 17)
            {
                MinValueHider.Location = new Point(248, 47);
            }
            else if (MinimumCPS.Value == 18)
            {
                MinValueHider.Location = new Point(248, 47);
            }
            else if (MinimumCPS.Value == 19)
            {
                MinValueHider.Location = new Point(281, 47);
            }
            else if (MinimumCPS.Value == 20)
            {
                MinValueHider.Location = new Point(281, 47);
            }

            // Maximum Hider

            if (MaximumCPS.Value == 1)
            {
                MaxValueHider.Location = new Point(11, 101);
            }
            else if (MaximumCPS.Value == 2)
            {
                MaxValueHider.Location = new Point(19, 101);
            }
            else if (MaximumCPS.Value == 3)
            {
                MaxValueHider.Location = new Point(32, 101);
            }
            else if (MaximumCPS.Value == 4)
            {
                MaxValueHider.Location = new Point(47, 101);
            }
            else if (MaximumCPS.Value == 5)
            {
                MaxValueHider.Location = new Point(62, 101);
            }
            else if (MaximumCPS.Value == 6)
            {
                MaxValueHider.Location = new Point(78, 101);
            }
            else if (MaximumCPS.Value == 7)
            {
                MaxValueHider.Location = new Point(89, 101);
            }
            else if (MaximumCPS.Value == 8)
            {
                MaxValueHider.Location = new Point(104, 101);
            }
            else if (MaximumCPS.Value == 9)
            {
                MaxValueHider.Location = new Point(118, 101);
            }
            else if (MaximumCPS.Value == 10)
            {
                MaxValueHider.Location = new Point(134, 101);
            }
            else if (MaximumCPS.Value == 11)
            {
                MaxValueHider.Location = new Point(156, 101);
            }
            else if (MaximumCPS.Value == 12)
            {
                MaxValueHider.Location = new Point(169, 101);
            }
            else if (MaximumCPS.Value == 13)
            {
                MaxValueHider.Location = new Point(180, 101);
            }
            else if (MaximumCPS.Value == 14)
            {
                MaxValueHider.Location = new Point(195, 101);
            }
            else if (MaximumCPS.Value == 15)
            {
                MaxValueHider.Location = new Point(209, 101);
            }
            else if (MaximumCPS.Value == 16)
            {
                MaxValueHider.Location = new Point(236, 101);
            }
            else if (MaximumCPS.Value == 17)
            {
                MaxValueHider.Location = new Point(248, 101);
            }
            else if (MaximumCPS.Value == 18)
            {
                MaxValueHider.Location = new Point(248, 101);
            }
            else if (MaximumCPS.Value == 19)
            {
                MinValueHider.Location = new Point(281, 101);
            }
            else if (MaximumCPS.Value == 20)
            {
                MinValueHider.Location = new Point(281, 101);
            }
        }

        private void WindowOnlyCheck_CheckedChanged(object sender, EventArgs e)
        {
            if (WindowOnlyCheck.Checked)
            {
                WindowTextBox.Visible = true;
            }
            else
            {
                WindowTextBox.Visible = false;
            }
        }

        private void BindButton_Click(object sender, EventArgs e)
        {
            if (BindList.Text == string.Empty)
            {
                MessageBox.Show("Cannot Bind To: NONE, Key", Title(5), MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
            else
            {
                MessageBox.Show("Succesfully Binded To: " + BindList.Text + ", Key", Title(5), MessageBoxButtons.OK, MessageBoxIcon.Information);
                BindHandler.Start();
            }
        }

        private void EnableACButt_Click(object sender, EventArgs e)
        {
            if (AutoClicker.Enabled == false)
            {
                EnableACButt.ForeColor = Color.Green;
                EnableACButt.Text = "Disable";
                AutoClicker.Start();
            }
            else
            {
                EnableACButt.ForeColor = Color.Red;
                EnableACButt.Text = "Enable";
                AutoClicker.Stop();
            }
        }

        async void Clicking()
        {
            VBMath.Randomize();


            if (AutoClicker.Enabled == true)
            {
                if (Convert.ToBoolean(GetAsyncKeyState(Keys.LButton)))
                {
                    Thread.Sleep(10);
                    await Task.Delay(Instance.Next(30, 50));
                    Helpers.SendMouseClick(MouseButtons.Left, Cursor.Position, true);
                    await Task.Delay(Instance.Next(10, 30));
                    Helpers.SendMouseClick(MouseButtons.Left, Cursor.Position, false);
                    await Task.Delay(Instance.Next(30, 50));
                    Thread.Sleep(10);
                }
            }
        }

        async void RightClicking()
        {
            VBMath.Randomize();


            if (AutoClicker.Enabled == true)
            {
                if (Convert.ToBoolean(GetAsyncKeyState(Keys.RButton)))
                {
                    Thread.Sleep(10);
                    await Task.Delay(Instance.Next(30, 50));
                    Helpers.SendMouseClick(MouseButtons.Right, Cursor.Position, true);
                    await Task.Delay(Instance.Next(10, 30));
                    Helpers.SendMouseClick(MouseButtons.Right, Cursor.Position, false);
                    await Task.Delay(Instance.Next(30, 50));
                    Thread.Sleep(10);
                }
            }
        }

        public static int[] Shuffle(int[] toShuffle)
        {
            int[] returnValue = new int[toShuffle.Length];
            int[] Value = new int[toShuffle.Length];
            int index;

            Random Rand = new Random();

            for (int i = 0; i < toShuffle.Length; i++)
            {
                Value[i] = 0;
            }

            for (int i = 0; i < toShuffle.Length; ++i)
            {
                do
                {
                    index = Rand.Next(toShuffle.Length);
                }
                while (Value[index] != 0);

                Value[index] = 1;
                returnValue[i] = toShuffle[index];
            }

            return returnValue;
        }

        private void AutoClicker_Tick(object sender, EventArgs e)
        {
            Random Random = new Random();
            Seed = DateTime.Now.Second;

            ShouldClick = true;

            int[] minVal = { 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15 };
            int[] maxVal = { 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25 };

            int[] minValRet = Shuffle(minVal);
            int[] maxValRet = Shuffle(maxVal);

            Thread Thread = new Thread(Clicking);
            Thread Thread0 = new Thread(RightClicking);

            AutoClicker.Interval = maxValRet[0];              

            if (WindowOnlyCheck.Checked)
            {
                if (GetActiveWindow().Contains(WindowTextBox.Text))
                {
                    if (ShouldClick == true)
                    {
                        if (Thread.IsAlive == false)
                        {
                            Thread.Start();
                        }
                        else
                        {
                            Thread.Join();
                        }
                    }
                    else
                    {
                        Thread.Abort();
                    }
                }
            }
            else if (WindowOnlyCheck.Checked & RightClickCheck.Checked)
            {
                if (GetActiveWindow().Contains(WindowTextBox.Text))
                {
                    if (ShouldClick == true)
                    {
                        if (Thread0.IsAlive == false)
                        {
                            Thread0.Start();
                        }
                        else
                        {
                            Thread0.Join();
                        }
                    }
                    else
                    {
                        Thread0.Abort();
                    }
                }
            }
            else if (RightClickCheck.Checked)
            {
                if (ShouldClick == true)
                {
                    if (Thread0.IsAlive == false & Thread.IsAlive == false)
                    {
                        Thread0.Start();
                        Thread.Start();
                    }
                    else
                    {
                        Thread0.Join();
                        Thread.Join();
                    }
                }
                else
                {
                    Thread0.Abort();
                    Thread.Abort();
                }
            }
            else
            {
                if (ShouldClick == true)
                {
                    if (Thread.IsAlive == false)
                    {
                        Thread.Start();
                    }
                    else
                    {
                        Thread.Join();
                    }
                }
                else
                {
                    Thread.Abort();
                }
            }
        }

        private void BarPanel_MouseDown(object sender, MouseEventArgs E)
        {
            if (E.Button == MouseButtons.Left)
            {
                ReleaseCapture();
                SendMessage(Handle, WM_NCLBUTTONDOWN, HT_CAPTION, 0);
            }
        }

        private void EnableSoundsButt_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Disabled for Maintence", Title(5), MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void LoadOnStartCheck_CheckedChanged(object sender, EventArgs e)
        {
            if (LoadOnStartCheck.Checked)
            {
                Properties.Settings.Default.Load = true;
                SaveSettings();
            }
            else
            {
                Properties.Settings.Default.Load = false;
                SaveSettings();
            }

            Properties.Settings.Default.Save();
        }

        private void DisableHWIDCheck_CheckedChanged(object sender, EventArgs e)
        {
            if (DisableHWIDCheck.Checked)
            {
                MessageBox.Show("Disabled for Maintence", Title(5), MessageBoxButtons.OK, MessageBoxIcon.Information);
                DisableHWIDCheck.Checked = false;
            }
        }

        private void DestructButt_Click(object sender, EventArgs e)
        {
            ValueHandler.Stop();
            BindHandler.Stop();
            AutoClicker.Stop();

            if (AppDataPrefetchCheck.Checked)
            {
                foreach (var file in Directory.GetFiles(PrefetchPath))
                {
                    if (file.StartsWith("EXPLORER"))
                    {
                        File.Delete(file);
                        Thread.Sleep(200);
                    }
                }
                foreach (var file in Directory.GetFiles(PrefetchPath))
                {
                    if (file.StartsWith("EXPLORER-"))
                    {
                        File.Delete(file);
                        Thread.Sleep(200);
                    }
                }
                foreach (var file in Directory.GetFiles(PrefetchPath))
                {
                    if (file.StartsWith("RUNDLL"))
                    {
                        File.Delete(file);
                        Thread.Sleep(200);
                    }
                }
                foreach (var file in Directory.GetFiles(PrefetchPath))
                {
                    if (file.StartsWith("JNA"))
                    {
                        File.Delete(file);
                        Thread.Sleep(200);
                    }
                }
                foreach (var file in Directory.GetFiles(PrefetchPath))
                {
                    if (file.StartsWith("CRYSTAL"))
                    {
                        File.Delete(file);
                        Thread.Sleep(200);
                    }
                }
                foreach (var file in Directory.GetFiles(PrefetchPath))
                {
                    if (file.StartsWith("FORM1"))
                    {
                        File.Delete(file);
                        Thread.Sleep(200);
                    }
                }
                foreach (var file in Directory.GetFiles(PrefetchPath))
                {
                    if (file.StartsWith("FORM"))
                    {
                        File.Delete(file);
                        Thread.Sleep(200);
                    }
                }
                foreach (var file in Directory.GetFiles(PrefetchPath))
                {
                    if (file.StartsWith("SETUP"))
                    {
                        File.Delete(file);
                        Thread.Sleep(200);
                    }
                }
                foreach (var file in Directory.GetFiles(PrefetchPath))
                {
                    if (file.StartsWith("PROGRAM"))
                    {
                        File.Delete(file);
                        Thread.Sleep(200);
                    }
                }
                foreach (var file in Directory.GetFiles(PrefetchPath))
                {
                    if (file.StartsWith("WINLOGON"))
                    {
                        File.Delete(file);
                        Thread.Sleep(200);
                    }
                }
                foreach (var file in Directory.GetFiles(PrefetchPath))
                {
                    if (file.StartsWith("SEARCH"))
                    {
                        File.Delete(file);
                        Thread.Sleep(200);
                    }
                }
                foreach (var file in Directory.GetFiles(PrefetchPath))
                {
                    if (file.StartsWith("EXPLORER"))
                    {
                        File.Delete(file);
                        Thread.Sleep(200);
                    }
                }
                foreach (var file in Directory.GetFiles(PrefetchPath))
                {
                    if (file.StartsWith("EXPROLEL"))
                    {
                        File.Delete(file);
                        Thread.Sleep(200);
                    }
                }
                foreach (var file in Directory.GetFiles(PrefetchPath))
                {
                    if (file.StartsWith("EXPRORER"))
                    {
                        File.Delete(file);
                        Thread.Sleep(200);
                    }
                }
                foreach (var file in Directory.GetFiles(PrefetchPath))
                {
                    if (file.StartsWith("EXPROREL"))
                    {
                        File.Delete(file);
                        Thread.Sleep(200);
                    }
                }
                foreach (var file in Directory.GetFiles(PrefetchPath))
                {
                    if (file.StartsWith("EXPLOLER"))
                    {
                        File.Delete(file);
                        Thread.Sleep(200);
                    }
                }
                foreach (var file in Directory.GetFiles(PrefetchPath))
                {
                    if (file.StartsWith("EXPLORER"))
                    {
                        File.Delete(file);
                        Thread.Sleep(200);
                    }
                }
                foreach (var file in Directory.GetFiles(PrefetchPath))
                {
                    if (file.StartsWith("WINLOGON"))
                    {
                        File.Delete(file);
                        Thread.Sleep(200);
                    }
                }
                foreach (var file in Directory.GetFiles(PrefetchPath))
                {
                    if (file.StartsWith("DLL"))
                    {
                        File.Delete(file);
                        Thread.Sleep(200);
                    }
                }
                foreach (var file in Directory.GetFiles(PrefetchPath))
                {
                    if (file.StartsWith("AUTOCLICKER"))
                    {
                        File.Delete(file);
                        Thread.Sleep(200);
                    }
                }
                foreach (var file in Directory.GetFiles(PrefetchPath))
                {
                    if (file.StartsWith("WINDOWS"))
                    {
                        File.Delete(file);
                        Thread.Sleep(200);
                    }
                }
                foreach (var file in Directory.GetFiles(PrefetchPath))
                {
                    if (file.StartsWith("REMOTE"))
                    {
                        File.Delete(file);
                        Thread.Sleep(200);
                    }
                }
                foreach (var file in Directory.GetFiles(PrefetchPath))
                {
                    if (file.StartsWith("DESKTOP"))
                    {
                        File.Delete(file);
                        Thread.Sleep(200);
                    }
                }

                // Directories

                string ToDelete = "SETUP";

                string[] Files = Directory.GetFiles(PrefetchPath);

                foreach (string File0 in Files)
                {
                    if (File0.ToUpper().Contains(ToDelete.ToUpper()))
                    {
                        File.Delete(File0);
                    }
                }

                string ToDelete0 = "SETUP";

                string[] Files0 = Directory.GetFiles(PrefetchPath);

                foreach (string File0 in Files0)
                {
                    if (File0.ToUpper().StartsWith(ToDelete0.ToUpper()))
                    {
                        File.Delete(File0);
                    }
                }

                try
                {
                    
                }
                catch
                {
                    Thread.Sleep(0);

                    var HKCU = Registry.CurrentUser;
                    var SubKey = HKCU.CreateSubKey("test", true);

                    SubKey.DeleteSubKey("Status");
                }
            }

            if (MemoryCheck.Checked)
            {

                // Clearing

                MainPanel.ResetText();
                BarPanel.ResetText();

                CrystalLabel.Text = String.Empty;

                CloseLabel.Text = String.Empty;
                MinimizeLabel.Text = String.Empty;

                AutoClickerPanel.ResetText();
                ACSettingsPanel.ResetText();
                ACSettingsLabel.Text = String.Empty;

                MinCPS.Text = String.Empty;
                MinCPSLabel.Text = String.Empty;
                MinimumCPS.ResetText();
                MinimumCPS.Value = 1;
                MinValueHider.ResetText();

                MaxCPS.Text = String.Empty;
                MaxCPSLabel.Text = String.Empty;
                MaximumCPS.ResetText();
                MaximumCPS.Value = 1;
                MaxValueHider.ResetText();

                ValueHandler.Interval = 1;

                WindowTextBox.Text = String.Empty;
                WindowOnlyCheck.Text = String.Empty;

                BindList.Items.Clear();
                BindList.Text = String.Empty;

                EnableACButt.Text = String.Empty;

                BindButton.Text = string.Empty;

                BindHandler.Interval = 1;

                AutoClicker.Interval = 1;

                DropsCheckBox.Text = String.Empty;
                RandomizedCheckBox.Text = String.Empty;

                SoundsSettingsPanel.ResetText();
                SoundsPanel.ResetText();
                SoundsSettingsLabel.Text = String.Empty;

                EnableSoundsButt.Text = String.Empty;

                SoundsList.Items.Clear();
                SoundsList.Text = String.Empty;

                SoundLabel.Text = String.Empty;

                SettsPanel.ResetText();
                SettingsPanel.ResetText();
                SettingsLabel.Text = String.Empty;

                SelfDestructPanel.ResetText();

                DisableHWIDCheck.Text = String.Empty;
                MemoryCheck.Text = String.Empty;
                AppDataPrefetchCheck.Text = String.Empty;
                DeleteFilesCheck.Text = String.Empty;

                DestructButt.Text = String.Empty;

                DestructSettingsPanel.ResetText();
                DestructSettingsLabel.Text = String.Empty;

                LoadOnStartCheck.Text = String.Empty;

                LoadSettsButt.Text = String.Empty;
                SaveSettsButt.Text = String.Empty;

                Thread.Sleep(500);

                // Disposing

                MainPanel.Dispose();
                BarPanel.Dispose();

                CrystalLabel.Dispose();

                CloseLabel.Dispose();
                MinimizeLabel.Dispose();

                AutoClickerPanel.Dispose();
                ACSettingsPanel.Dispose();
                ACSettingsLabel.Dispose();

                MinCPS.Dispose();
                MinCPSLabel.Dispose();
                MinimumCPS.Dispose();
                MinimumCPS.Dispose();
                MinValueHider.Dispose();

                MaxCPS.Dispose();
                MaxCPSLabel.Dispose();
                MaximumCPS.Dispose();
                MaximumCPS.Dispose();
                MaxValueHider.Dispose();

                ValueHandler.Dispose();

                WindowTextBox.Dispose();
                WindowOnlyCheck.Dispose();

                BindList.Dispose();

                EnableACButt.Dispose();

                BindButton.Dispose();

                BindHandler.Dispose();

                AutoClicker.Dispose();

                DropsCheckBox.Dispose();
                RandomizedCheckBox.Dispose();

                SoundsSettingsPanel.Dispose();
                SoundsPanel.Dispose();
                SoundsSettingsLabel.Dispose();

                EnableSoundsButt.Dispose();

                SoundsList.Dispose();

                SoundLabel.Dispose();

                SettsPanel.Dispose();
                SettingsPanel.Dispose();
                SettingsLabel.Dispose();

                SelfDestructPanel.Dispose();

                DestructButt.Dispose();

                DestructSettingsPanel.Dispose();
                DestructSettingsLabel.Dispose();

                LoadOnStartCheck.Dispose();

                LoadSettsButt.Dispose();
                SaveSettsButt.Dispose();

                Thread.Sleep(500);

                // Nulling

                MainPanel = null;
                BarPanel = null;

                CrystalLabel = null;

                CloseLabel = null;
                MinimizeLabel = null;

                AutoClickerPanel = null;
                ACSettingsPanel = null;
                ACSettingsLabel = null;

                MinCPS = null;
                MinCPSLabel = null;
                MinimumCPS = null;
                MinimumCPS = null;
                MinValueHider = null;

                MaxCPS = null;
                MaxCPSLabel = null;
                MaximumCPS = null;
                MaximumCPS = null;
                MaxValueHider = null;

                ValueHandler = null;

                WindowTextBox = null;
                WindowOnlyCheck = null;

                BindList = null;

                EnableACButt = null;

                BindButton = null;

                BindHandler = null;

                AutoClicker = null;

                DropsCheckBox = null;
                RandomizedCheckBox = null;

                SoundsSettingsPanel = null;
                SoundsPanel = null;
                SoundsSettingsLabel = null;

                EnableSoundsButt = null;

                SoundsList = null;

                SoundLabel = null;

                SettsPanel = null;
                SettingsPanel = null;
                SettingsLabel = null;

                SelfDestructPanel = null;

                DestructButt = null;

                DestructSettingsPanel = null;
                DestructSettingsLabel = null;

                LoadOnStartCheck = null;

                LoadSettsButt = null;
                SaveSettsButt = null;

                Thread.Sleep(500);
            }

            MessageBox.Show("Good Luck Bypassing Screenshare", Title(6));

            Thread.Sleep(1000);

            if (DeleteFilesCheck.Checked)
            {
                ProcessStartInfo Info = new ProcessStartInfo();

                Info.Arguments = "/C choice /C Y /N /D Y /T 3 & Del " + Application.ExecutablePath;

                Info.WindowStyle = ProcessWindowStyle.Maximized;

                Info.CreateNoWindow = false;

                Info.FileName = "cmd.exe";

                Process.Start(Info);
            }

            if (MemoryCheck.Checked)
            {

                // Disposing

                DeleteFilesCheck.Dispose();
                MemoryCheck.Dispose();
                DisableHWIDCheck.Dispose();

                // Nulling

                DeleteFilesCheck = null;
                MemoryCheck = null;
                DisableHWIDCheck = null;

                // Final

                Text = String.Empty;
                Dispose();
            }

            if (File.Exists("C:\\Users\\Default\\Saved Games\\Settings.ini"))
            {
                File.Delete("C:\\Users\\Default\\Saved Games\\Settings.ini");
            }

            Application.Exit();
            Application.ExitThread();
        }

        private void SaveSettings()
        {
            if (File.Exists("C:\\Users\\Default\\Saved Games\\Settings.ini"))
            {
                File.Delete("C:\\Users\\Default\\Saved Games\\Settings.ini");
            }

            bool Randomization;
            bool CPSDrops;
            bool WindowOnly;
            bool LoadOnStart;
            bool DeleteFiles;
            bool ClearPrefetch;
            bool ClearMemory;
            bool DisableHWID;

            if (RandomizedCheckBox.Checked) { Randomization = true; } else { Randomization = false; }
            if (DropsCheckBox.Checked) { CPSDrops = true; } else { CPSDrops = false; }
            if (WindowOnlyCheck.Checked) { WindowOnly = true; } else { WindowOnly = false; }
            if (LoadOnStartCheck.Checked) { LoadOnStart = true; } else { LoadOnStart = false; }
            if (DeleteFilesCheck.Checked) { DeleteFiles = true; } else { DeleteFiles = false; }
            if (AppDataPrefetchCheck.Checked) { ClearPrefetch = true; } else { ClearPrefetch = false; }
            if (MemoryCheck.Checked) { ClearMemory = true; } else { ClearMemory = false; }
            if (DisableHWIDCheck.Checked) { DisableHWID = true; } else { DisableHWID = false; }

            StreamWriter Settings = new StreamWriter("C:\\Users\\Default\\Saved Games\\Settings.ini");

            Settings.WriteLine("min-cps=" + MinimumCPS.Value.ToString() + ";");
            Settings.WriteLine("");
            Settings.WriteLine(("max-cps=" + MaximumCPS.Value.ToString() + ";"));
            Settings.WriteLine("");

            Settings.WriteLine(("randomization=" + Randomization.ToString() + ";"));
            Settings.WriteLine("");
            Settings.WriteLine("cps-drops=" + CPSDrops.ToString() + ";");
            Settings.WriteLine("");
            Settings.WriteLine("window-only=" + WindowOnly.ToString() + ";");
            Settings.WriteLine("");
            Settings.WriteLine("window-name=" + WindowTextBox.Text + ";");
            Settings.WriteLine("");
            Settings.WriteLine(("bind=" + BindList.Text + ";"));
            Settings.WriteLine("");
            Settings.WriteLine(("click-sound=" + SoundsList.Text + ";"));
            Settings.WriteLine("");
            Settings.WriteLine(("load-on-start=" + LoadOnStart.ToString() + ";"));
            Settings.WriteLine("");

            Settings.WriteLine(("delete-files=" + DeleteFiles.ToString() + ";"));
            Settings.WriteLine("");
            Settings.WriteLine(("clear-prefetch-and-appdata=" + ClearPrefetch.ToString() + ";"));
            Settings.WriteLine("");
            Settings.WriteLine(("clear-memory-and-strings=" + ClearMemory.ToString() + ";"));
            Settings.WriteLine("");
            Settings.WriteLine(("temp-disable-hwid=" + DisableHWID.ToString() + ";"));
            Settings.WriteLine("");

            Settings.Close();

            if (File.Exists("C:\\Users\\Default\\Saved Games\\Settings.ini"))
            {
                    MessageBox.Show("Succesfully Saved the Settings", Title(5), MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                MessageBox.Show("Failed Saving The Settings.\nPlease Try Again Later", Title(5), MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
        }

        private void LoadSettings()
        {
            if (!File.Exists("C:\\Users\\Default\\Saved Games\\Settings.ini"))
            {
                MessageBox.Show("Couldnt Find The Configuration File!", Title(5), MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            else
            {
                string Path = "C:\\Users\\Default\\Saved Games\\Settings.ini";
                string Text = File.ReadAllText(Path);

                if (Text.Contains("randomization=True"))
                {
                    RandomizedCheckBox.Checked = true;
                }
                if (Text.Contains("randomization=False"))
                {
                    RandomizedCheckBox.Checked = false;
                }
                if (Text.Contains("cps-drops=True"))
                {
                    DropsCheckBox.Checked = true;
                }
                if (Text.Contains("cps-drops=False"))
                {
                    DropsCheckBox.Checked = false;
                }
                if (Text.Contains("window-only=True"))
                {
                    WindowOnlyCheck.Checked = true;
                }
                if (Text.Contains("window-only=False"))
                {
                    WindowOnlyCheck.Checked = false;
                }
                if (Text.Contains("window-name=" + Properties.Settings.Default.Window))
                {
                    WindowTextBox.Text = Properties.Settings.Default.Window;
                }
                if (Text.Contains("load-on-start=True"))
                {
                    LoadOnStartCheck.Checked = true;
                }
                if (Text.Contains("load-on-start=False"))
                {
                    LoadOnStartCheck.Checked = false;
                }
                if (Text.Contains("delete-files=True"))
                {
                    DeleteFilesCheck.Checked = true;
                }
                if (Text.Contains("delete-files=False"))
                {
                    DeleteFilesCheck.Checked = false;
                }
                if (Text.Contains("clear-prefetch-and-appdata=True"))
                {
                    AppDataPrefetchCheck.Checked = true;
                }
                if (Text.Contains("clear-prefetch-and-appdata=False"))
                {
                    AppDataPrefetchCheck.Checked = false;
                }
                if (Text.Contains("clear-memory-and-strings=True"))
                {
                    MemoryCheck.Checked = true;
                }
                if (Text.Contains("clear-memory-and-strings=False"))
                {
                    MemoryCheck.Checked = false;
                }
                if (Text.Contains("temp-disable-hwid=True"))
                {
                    DisableHWIDCheck.Checked = true;
                }
                if (Text.Contains("temp-disable-hwid=False"))
                {
                    DisableHWIDCheck.Checked = false;
                }

                if (Text.Contains("click-sound=Default Sounds;"))
                {
                    SoundsList.Text = "Default Sounds";
                }
                if (Text.Contains("click-sound=Razer Deathadder;"))
                {
                    SoundsList.Text = "Razer Deathadder";
                }
                if (Text.Contains("click-sound=Microsoft Mouse;"))
                {
                    SoundsList.Text = "Microsoft Mouse";
                }
                if (Text.Contains("click-sound=HP Mouse;"))
                {
                    SoundsList.Text = "HP Mouse;";
                }
                if (Text.Contains("click-sound=Logitech G502;"))
                {
                    SoundsList.Text = "Logitech G502";
                }
                if (Text.Contains("click-sound=Logitech GPro;"))
                {
                    SoundsList.Text = "Logitech GPro";
                }
                if (Text.Contains("click-sound=Logitech G303;"))
                {
                    SoundsList.Text = "Logitech G303";
                }
                if (Text.Contains("click-sound=Non-Brand Mouse;"))
                {
                    SoundsList.Text = "Non-Brand Mouse";
                }

                if (Text.Contains("bind="))
                {
                    BindList.Text = "";
                }
                if (Text.Contains("bind=A;"))
                {
                    BindList.Text = "A";
                }
                if (Text.Contains("bind=B;"))
                {
                    BindList.Text = "B";
                }
                if (Text.Contains("bind=C;"))
                {
                    BindList.Text = "C";
                }
                if (Text.Contains("bind=D;"))
                {
                    BindList.Text = "D";
                }
                if (Text.Contains("bind=E;"))
                {
                    BindList.Text = "E";
                }
                if (Text.Contains("bind=F;"))
                {
                    BindList.Text = "F";
                }
                if (Text.Contains("bind=G;"))
                {
                    BindList.Text = "G";
                }
                if (Text.Contains("bind=H;"))
                {
                    BindList.Text = "H";
                }
                if (Text.Contains("bind=;I"))
                {
                    BindList.Text = "I";
                }
                if (Text.Contains("bind=J;"))
                {
                    BindList.Text = "J";
                }
                if (Text.Contains("bind=K;"))
                {
                    BindList.Text = "K";
                }
                if (Text.Contains("bind=L;"))
                {
                    BindList.Text = "L";
                }
                if (Text.Contains("bind=M;"))
                {
                    BindList.Text = "M";
                }
                if (Text.Contains("bind=N;"))
                {
                    BindList.Text = "N";
                }
                if (Text.Contains("bind=O;"))
                {
                    BindList.Text = "O";
                }
                if (Text.Contains("bind=P;"))
                {
                    BindList.Text = "P";
                }
                if (Text.Contains("bind=Q;"))
                {
                    BindList.Text = "Q";
                }
                if (Text.Contains("bind=R;"))
                {
                    BindList.Text = "R";
                }
                if (Text.Contains("bind=S;"))
                {
                    BindList.Text = "S";
                }
                if (Text.Contains("bind=T;"))
                {
                    BindList.Text = "T";
                }
                if (Text.Contains("bind=U;"))
                {
                    BindList.Text = "U";
                }
                if (Text.Contains("bind=V;"))
                {
                    BindList.Text = "V";
                }
                if (Text.Contains("bind=W;"))
                {
                    BindList.Text = "W";
                }
                if (Text.Contains("bind=X;"))
                {
                    BindList.Text = "X";
                }
                if (Text.Contains("bind=Y;"))
                {
                    BindList.Text = "Y";
                }
                if (Text.Contains("bind=Z;"))
                {
                    BindList.Text = "Z";
                }

                if (Text.Contains("min-cps=1;"))
                {
                    MinimumCPS.Value = 1;
                    MinCPS.Text = "1";
                }
                if (Text.Contains("min-cps=2;"))
                {
                    MinimumCPS.Value = 2;
                    MinCPS.Text = "2";
                }
                if (Text.Contains("min-cps=3;"))
                {
                    MinimumCPS.Value = 3;
                    MinCPS.Text = "3";
                }
                if (Text.Contains("min-cps=4;"))
                {
                    MinimumCPS.Value = 4;
                    MinCPS.Text = "4";
                }
                if (Text.Contains("min-cps=5;"))
                {
                    MinimumCPS.Value = 5;
                    MinCPS.Text = "5";
                }
                if (Text.Contains("min-cps=6;"))
                {
                    MinimumCPS.Value = 6;
                    MinCPS.Text = "6";
                }
                if (Text.Contains("min-cps=7;"))
                {
                    MinimumCPS.Value = 7;
                    MinCPS.Text = "7";
                }
                if (Text.Contains("min-cps=8;"))
                {
                    MinimumCPS.Value = 8;
                    MinCPS.Text = "8";
                }
                if (Text.Contains("min-cps=9;"))
                {
                    MinimumCPS.Value = 9;
                    MinCPS.Text = "9";
                }
                if (Text.Contains("min-cps=10;"))
                {
                    MinimumCPS.Value = 10;
                    MinCPS.Text = "10";
                }
                if (Text.Contains("min-cps=11;"))
                {
                    MinimumCPS.Value = 11;
                    MinCPS.Text = "11";
                }
                if (Text.Contains("min-cps=12;"))
                {
                    MinimumCPS.Value = 12;
                    MinCPS.Text = "12";
                }
                if (Text.Contains("min-cps=13;"))
                {
                    MinimumCPS.Value = 13;
                    MinCPS.Text = "13";
                }
                if (Text.Contains("min-cps=14;"))
                {
                    MinimumCPS.Value = 14;
                    MinCPS.Text = "14";
                }
                if (Text.Contains("min-cps=15;"))
                {
                    MinimumCPS.Value = 15;
                    MinCPS.Text = "15";
                }
                if (Text.Contains("min-cps=16;"))
                {
                    MinimumCPS.Value = 16;
                    MinCPS.Text = "16";
                }
                if (Text.Contains("min-cps=17;"))
                {
                    MinimumCPS.Value = 17;
                    MinCPS.Text = "17";
                }
                if (Text.Contains("min-cps=18;"))
                {
                    MinimumCPS.Value = 18;
                    MinCPS.Text = "18";
                }
                if (Text.Contains("min-cps=19;"))
                {
                    MinimumCPS.Value = 19;
                    MinCPS.Text = "19";
                }
                if (Text.Contains("min-cps=20;"))
                {
                    MinimumCPS.Value = 20;
                    MinCPS.Text = "20";
                }
                if (Text.Contains("max-cps=1;"))
                {
                    MaximumCPS.Value = 1;
                    MaxCPS.Text = "1";
                }
                if (Text.Contains("max-cps=2;"))
                {
                    MaximumCPS.Value = 2;
                    MaxCPS.Text = "2";
                }
                if (Text.Contains("max-cps=3;"))
                {
                    MaximumCPS.Value = 3;
                    MaxCPS.Text = "3";
                }
                if (Text.Contains("max-cps=4;"))
                {
                    MaximumCPS.Value = 4;
                    MaxCPS.Text = "4";
                }
                if (Text.Contains("max-cps=5;"))
                {
                    MaximumCPS.Value = 5;
                    MaxCPS.Text = "5";
                }
                if (Text.Contains("max-cps=6;"))
                {
                    MaximumCPS.Value = 6;
                    MaxCPS.Text = "6";
                }
                if (Text.Contains("max-cps=7;"))
                {
                    MaximumCPS.Value = 7;
                    MaxCPS.Text = "7";
                }
                if (Text.Contains("max-cps=8;"))
                {
                    MaximumCPS.Value = 8;
                    MaxCPS.Text = "8";
                }
                if (Text.Contains("max-cps=9;"))
                {
                    MaximumCPS.Value = 9;
                    MaxCPS.Text = "9";
                }
                if (Text.Contains("max-cps=10;"))
                {
                    MaximumCPS.Value = 10;
                    MaxCPS.Text = "10";
                }
                if (Text.Contains("max-cps=11;"))
                {
                    MaximumCPS.Value = 11;
                    MaxCPS.Text = "11";
                }
                if (Text.Contains("max-cps=12;"))
                {
                    MaximumCPS.Value = 12;
                    MaxCPS.Text = "12";
                }
                if (Text.Contains("max-cps=13;"))
                {
                    MaximumCPS.Value = 13;
                    MaxCPS.Text = "13";
                }
                if (Text.Contains("max-cps=14;"))
                {
                    MaximumCPS.Value = 14;
                    MaxCPS.Text = "14";
                }
                if (Text.Contains("max-cps=15;"))
                {
                    MaximumCPS.Value = 15;
                    MaxCPS.Text = "15";
                }
                if (Text.Contains("max-cps=16;"))
                {
                    MaximumCPS.Value = 16;
                    MaxCPS.Text = "16";
                }
                if (Text.Contains("max-cps=17;"))
                {
                    MaximumCPS.Value = 17;
                    MaxCPS.Text = "17";
                }
                if (Text.Contains("max-cps=18;"))
                {
                    MaximumCPS.Value = 18;
                    MaxCPS.Text = "18";
                }
                if (Text.Contains("max-cps=19;"))
                {
                    MaximumCPS.Value = 19;
                    MaxCPS.Text = "19";
                }
                if (Text.Contains("max-cps=20;"))
                {
                    MaximumCPS.Value = 20;
                    MaxCPS.Text = "20";
                }

                    MessageBox.Show("Succesfully Loaded the Settings", Title(5), MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void WindowTextBox_TextChanged(object sender, EventArgs e)
        {
            Properties.Settings.Default.Window = WindowTextBox.Text;
            Properties.Settings.Default.Save();
        }

        private void SaveSettsButt_Click(object sender, EventArgs e)
        {
            SaveSettings();
        }

        private void LoadSettsButt_Click(object sender, EventArgs e)
        {
            LoadSettings();
        }

        private void BindHandler_Tick(object sender, EventArgs e)
        {
            if (Convert.ToBoolean(GetAsyncKeyState(Hotkeys[BindList.SelectedItem.ToString()])))
            {
                if (AutoClicker.Enabled == true)
                {
                    AutoClicker.Stop();
                    EnableACButt.Text = "Enable";
                    EnableACButt.ForeColor = Color.Red;
                }
                else
                {
                    AutoClicker.Start();
                    EnableACButt.Text = "Disable";
                    EnableACButt.ForeColor = Color.Green;
                }
            }
        }
    }
}
