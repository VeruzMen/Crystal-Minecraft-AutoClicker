﻿namespace AutoClicker.Main
{
    partial class Main
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.MainPanel = new System.Windows.Forms.Panel();
            this.SettsPanel = new System.Windows.Forms.Panel();
            this.LoadOnStartCheck = new System.Windows.Forms.CheckBox();
            this.LoadSettsButt = new System.Windows.Forms.Button();
            this.SaveSettsButt = new System.Windows.Forms.Button();
            this.SettingsPanel = new System.Windows.Forms.Panel();
            this.SettingsLabel = new System.Windows.Forms.Label();
            this.SelfDestructPanel = new System.Windows.Forms.Panel();
            this.DisableHWIDCheck = new System.Windows.Forms.CheckBox();
            this.MemoryCheck = new System.Windows.Forms.CheckBox();
            this.AppDataPrefetchCheck = new System.Windows.Forms.CheckBox();
            this.DeleteFilesCheck = new System.Windows.Forms.CheckBox();
            this.DestructButt = new System.Windows.Forms.Button();
            this.DestructSettingsPanel = new System.Windows.Forms.Panel();
            this.DestructSettingsLabel = new System.Windows.Forms.Label();
            this.SoundsPanel = new System.Windows.Forms.Panel();
            this.SoundsList = new System.Windows.Forms.ComboBox();
            this.SoundLabel = new System.Windows.Forms.Label();
            this.EnableSoundsButt = new System.Windows.Forms.Button();
            this.SoundsSettingsPanel = new System.Windows.Forms.Panel();
            this.SoundsSettingsLabel = new System.Windows.Forms.Label();
            this.ACSettingsPanel = new System.Windows.Forms.Panel();
            this.ACSettingsLabel = new System.Windows.Forms.Label();
            this.AutoClickerPanel = new System.Windows.Forms.Panel();
            this.DropsCheckBox = new System.Windows.Forms.CheckBox();
            this.RandomizedCheckBox = new System.Windows.Forms.CheckBox();
            this.BindButton = new System.Windows.Forms.Button();
            this.EnableACButt = new System.Windows.Forms.Button();
            this.BindList = new System.Windows.Forms.ComboBox();
            this.WindowTextBox = new System.Windows.Forms.TextBox();
            this.WindowOnlyCheck = new System.Windows.Forms.CheckBox();
            this.MinValueHider = new System.Windows.Forms.Panel();
            this.MaxValueHider = new System.Windows.Forms.Panel();
            this.MaximumCPS = new System.Windows.Forms.TrackBar();
            this.MaxCPS = new System.Windows.Forms.Label();
            this.MaxCPSLabel = new System.Windows.Forms.Label();
            this.MinCPS = new System.Windows.Forms.Label();
            this.MinimumCPS = new System.Windows.Forms.TrackBar();
            this.MinCPSLabel = new System.Windows.Forms.Label();
            this.BarPanel = new System.Windows.Forms.Panel();
            this.MinimizeLabel = new System.Windows.Forms.Label();
            this.CloseLabel = new System.Windows.Forms.Label();
            this.CrystalLabel = new System.Windows.Forms.Label();
            this.ValueHandler = new System.Windows.Forms.Timer(this.components);
            this.BindHandler = new System.Windows.Forms.Timer(this.components);
            this.AutoClicker = new System.Windows.Forms.Timer(this.components);
            this.RightClickCheck = new System.Windows.Forms.CheckBox();
            this.MainPanel.SuspendLayout();
            this.SettsPanel.SuspendLayout();
            this.SettingsPanel.SuspendLayout();
            this.SelfDestructPanel.SuspendLayout();
            this.DestructSettingsPanel.SuspendLayout();
            this.SoundsPanel.SuspendLayout();
            this.SoundsSettingsPanel.SuspendLayout();
            this.ACSettingsPanel.SuspendLayout();
            this.AutoClickerPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.MaximumCPS)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.MinimumCPS)).BeginInit();
            this.BarPanel.SuspendLayout();
            this.SuspendLayout();
            // 
            // MainPanel
            // 
            this.MainPanel.Controls.Add(this.SettsPanel);
            this.MainPanel.Controls.Add(this.SettingsPanel);
            this.MainPanel.Controls.Add(this.SelfDestructPanel);
            this.MainPanel.Controls.Add(this.DestructSettingsPanel);
            this.MainPanel.Controls.Add(this.SoundsPanel);
            this.MainPanel.Controls.Add(this.SoundsSettingsPanel);
            this.MainPanel.Controls.Add(this.ACSettingsPanel);
            this.MainPanel.Controls.Add(this.AutoClickerPanel);
            this.MainPanel.Controls.Add(this.BarPanel);
            this.MainPanel.Location = new System.Drawing.Point(2, 1);
            this.MainPanel.Name = "MainPanel";
            this.MainPanel.Size = new System.Drawing.Size(656, 398);
            this.MainPanel.TabIndex = 0;
            this.MainPanel.Paint += new System.Windows.Forms.PaintEventHandler(this.MainPanel_Paint);
            // 
            // SettsPanel
            // 
            this.SettsPanel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.SettsPanel.Controls.Add(this.LoadOnStartCheck);
            this.SettsPanel.Controls.Add(this.LoadSettsButt);
            this.SettsPanel.Controls.Add(this.SaveSettsButt);
            this.SettsPanel.Location = new System.Drawing.Point(338, 248);
            this.SettsPanel.Name = "SettsPanel";
            this.SettsPanel.Size = new System.Drawing.Size(308, 146);
            this.SettsPanel.TabIndex = 8;
            // 
            // LoadOnStartCheck
            // 
            this.LoadOnStartCheck.AutoSize = true;
            this.LoadOnStartCheck.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.LoadOnStartCheck.Location = new System.Drawing.Point(55, 115);
            this.LoadOnStartCheck.Name = "LoadOnStartCheck";
            this.LoadOnStartCheck.Size = new System.Drawing.Size(136, 27);
            this.LoadOnStartCheck.TabIndex = 2;
            this.LoadOnStartCheck.Text = "Load on Start";
            this.LoadOnStartCheck.UseVisualStyleBackColor = true;
            this.LoadOnStartCheck.CheckedChanged += new System.EventHandler(this.LoadOnStartCheck_CheckedChanged);
            // 
            // LoadSettsButt
            // 
            this.LoadSettsButt.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.LoadSettsButt.Font = new System.Drawing.Font("Calibri", 18.75F, System.Drawing.FontStyle.Bold);
            this.LoadSettsButt.ForeColor = System.Drawing.Color.Green;
            this.LoadSettsButt.Location = new System.Drawing.Point(55, 66);
            this.LoadSettsButt.Name = "LoadSettsButt";
            this.LoadSettsButt.Size = new System.Drawing.Size(196, 46);
            this.LoadSettsButt.TabIndex = 1;
            this.LoadSettsButt.Text = "Load Settings";
            this.LoadSettsButt.UseVisualStyleBackColor = true;
            this.LoadSettsButt.Click += new System.EventHandler(this.LoadSettsButt_Click);
            // 
            // SaveSettsButt
            // 
            this.SaveSettsButt.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.SaveSettsButt.Font = new System.Drawing.Font("Calibri", 18.75F, System.Drawing.FontStyle.Bold);
            this.SaveSettsButt.ForeColor = System.Drawing.Color.Green;
            this.SaveSettsButt.Location = new System.Drawing.Point(55, 14);
            this.SaveSettsButt.Name = "SaveSettsButt";
            this.SaveSettsButt.Size = new System.Drawing.Size(196, 46);
            this.SaveSettsButt.TabIndex = 0;
            this.SaveSettsButt.Text = "Save Settings";
            this.SaveSettsButt.UseVisualStyleBackColor = true;
            this.SaveSettsButt.Click += new System.EventHandler(this.SaveSettsButt_Click);
            // 
            // SettingsPanel
            // 
            this.SettingsPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(45)))), ((int)(((byte)(45)))), ((int)(((byte)(45)))));
            this.SettingsPanel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.SettingsPanel.Controls.Add(this.SettingsLabel);
            this.SettingsPanel.Location = new System.Drawing.Point(338, 219);
            this.SettingsPanel.Name = "SettingsPanel";
            this.SettingsPanel.Size = new System.Drawing.Size(308, 28);
            this.SettingsPanel.TabIndex = 7;
            // 
            // SettingsLabel
            // 
            this.SettingsLabel.AutoSize = true;
            this.SettingsLabel.Font = new System.Drawing.Font("Microsoft JhengHei", 12F);
            this.SettingsLabel.Location = new System.Drawing.Point(8, 3);
            this.SettingsLabel.Name = "SettingsLabel";
            this.SettingsLabel.Size = new System.Drawing.Size(146, 20);
            this.SettingsLabel.TabIndex = 8;
            this.SettingsLabel.Text = "Settings - Settings";
            // 
            // SelfDestructPanel
            // 
            this.SelfDestructPanel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.SelfDestructPanel.Controls.Add(this.DisableHWIDCheck);
            this.SelfDestructPanel.Controls.Add(this.MemoryCheck);
            this.SelfDestructPanel.Controls.Add(this.AppDataPrefetchCheck);
            this.SelfDestructPanel.Controls.Add(this.DeleteFilesCheck);
            this.SelfDestructPanel.Controls.Add(this.DestructButt);
            this.SelfDestructPanel.Location = new System.Drawing.Point(11, 310);
            this.SelfDestructPanel.Name = "SelfDestructPanel";
            this.SelfDestructPanel.Size = new System.Drawing.Size(320, 85);
            this.SelfDestructPanel.TabIndex = 6;
            // 
            // DisableHWIDCheck
            // 
            this.DisableHWIDCheck.AutoSize = true;
            this.DisableHWIDCheck.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.DisableHWIDCheck.Font = new System.Drawing.Font("Microsoft JhengHei Light", 10.25F);
            this.DisableHWIDCheck.Location = new System.Drawing.Point(137, 61);
            this.DisableHWIDCheck.Name = "DisableHWIDCheck";
            this.DisableHWIDCheck.Size = new System.Drawing.Size(158, 22);
            this.DisableHWIDCheck.TabIndex = 4;
            this.DisableHWIDCheck.Text = "Temp-Disable (HWID)";
            this.DisableHWIDCheck.UseVisualStyleBackColor = true;
            this.DisableHWIDCheck.CheckedChanged += new System.EventHandler(this.DisableHWIDCheck_CheckedChanged);
            // 
            // MemoryCheck
            // 
            this.MemoryCheck.AutoSize = true;
            this.MemoryCheck.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.MemoryCheck.Font = new System.Drawing.Font("Microsoft JhengHei Light", 10.25F);
            this.MemoryCheck.Location = new System.Drawing.Point(137, 43);
            this.MemoryCheck.Name = "MemoryCheck";
            this.MemoryCheck.Size = new System.Drawing.Size(176, 22);
            this.MemoryCheck.TabIndex = 3;
            this.MemoryCheck.Text = "Clear Memory + Strings";
            this.MemoryCheck.UseVisualStyleBackColor = true;
            // 
            // AppDataPrefetchCheck
            // 
            this.AppDataPrefetchCheck.AutoSize = true;
            this.AppDataPrefetchCheck.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.AppDataPrefetchCheck.Font = new System.Drawing.Font("Microsoft JhengHei Light", 10.25F);
            this.AppDataPrefetchCheck.Location = new System.Drawing.Point(137, 23);
            this.AppDataPrefetchCheck.Name = "AppDataPrefetchCheck";
            this.AppDataPrefetchCheck.Size = new System.Drawing.Size(182, 22);
            this.AppDataPrefetchCheck.TabIndex = 2;
            this.AppDataPrefetchCheck.Text = "Clear Prefetch + Registry";
            this.AppDataPrefetchCheck.UseVisualStyleBackColor = true;
            // 
            // DeleteFilesCheck
            // 
            this.DeleteFilesCheck.AutoSize = true;
            this.DeleteFilesCheck.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.DeleteFilesCheck.Font = new System.Drawing.Font("Microsoft JhengHei Light", 10.25F);
            this.DeleteFilesCheck.Location = new System.Drawing.Point(137, 4);
            this.DeleteFilesCheck.Name = "DeleteFilesCheck";
            this.DeleteFilesCheck.Size = new System.Drawing.Size(97, 22);
            this.DeleteFilesCheck.TabIndex = 1;
            this.DeleteFilesCheck.Text = "Delete Files";
            this.DeleteFilesCheck.UseVisualStyleBackColor = true;
            // 
            // DestructButt
            // 
            this.DestructButt.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.DestructButt.Font = new System.Drawing.Font("Calibri", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DestructButt.ForeColor = System.Drawing.Color.Red;
            this.DestructButt.Location = new System.Drawing.Point(8, 4);
            this.DestructButt.Name = "DestructButt";
            this.DestructButt.Size = new System.Drawing.Size(123, 76);
            this.DestructButt.TabIndex = 0;
            this.DestructButt.Text = "Destruct";
            this.DestructButt.UseVisualStyleBackColor = true;
            this.DestructButt.Click += new System.EventHandler(this.DestructButt_Click);
            // 
            // DestructSettingsPanel
            // 
            this.DestructSettingsPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(45)))), ((int)(((byte)(45)))), ((int)(((byte)(45)))));
            this.DestructSettingsPanel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.DestructSettingsPanel.Controls.Add(this.DestructSettingsLabel);
            this.DestructSettingsPanel.Location = new System.Drawing.Point(11, 281);
            this.DestructSettingsPanel.Name = "DestructSettingsPanel";
            this.DestructSettingsPanel.Size = new System.Drawing.Size(320, 28);
            this.DestructSettingsPanel.TabIndex = 5;
            // 
            // DestructSettingsLabel
            // 
            this.DestructSettingsLabel.AutoSize = true;
            this.DestructSettingsLabel.Font = new System.Drawing.Font("Microsoft JhengHei", 12F);
            this.DestructSettingsLabel.Location = new System.Drawing.Point(4, 3);
            this.DestructSettingsLabel.Name = "DestructSettingsLabel";
            this.DestructSettingsLabel.Size = new System.Drawing.Size(183, 20);
            this.DestructSettingsLabel.TabIndex = 6;
            this.DestructSettingsLabel.Text = "Self-Destruct - Settings";
            // 
            // SoundsPanel
            // 
            this.SoundsPanel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.SoundsPanel.Controls.Add(this.SoundsList);
            this.SoundsPanel.Controls.Add(this.SoundLabel);
            this.SoundsPanel.Controls.Add(this.EnableSoundsButt);
            this.SoundsPanel.Location = new System.Drawing.Point(338, 68);
            this.SoundsPanel.Name = "SoundsPanel";
            this.SoundsPanel.Size = new System.Drawing.Size(308, 144);
            this.SoundsPanel.TabIndex = 4;
            // 
            // SoundsList
            // 
            this.SoundsList.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(35)))), ((int)(((byte)(35)))), ((int)(((byte)(35)))));
            this.SoundsList.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.SoundsList.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.SoundsList.Font = new System.Drawing.Font("Microsoft JhengHei Light", 12.25F);
            this.SoundsList.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.SoundsList.FormattingEnabled = true;
            this.SoundsList.Items.AddRange(new object[] {
            "Default Sounds",
            "Razer Deathadder",
            "Microsoft Mouse",
            "HP Mouse",
            "Logitech G502",
            "Logitech GPro",
            "Logitech G303",
            "Non-Brand Mouse"});
            this.SoundsList.Location = new System.Drawing.Point(55, 92);
            this.SoundsList.Name = "SoundsList";
            this.SoundsList.Size = new System.Drawing.Size(196, 28);
            this.SoundsList.TabIndex = 5;
            // 
            // SoundLabel
            // 
            this.SoundLabel.AutoSize = true;
            this.SoundLabel.Location = new System.Drawing.Point(51, 66);
            this.SoundLabel.Name = "SoundLabel";
            this.SoundLabel.Size = new System.Drawing.Size(66, 23);
            this.SoundLabel.TabIndex = 1;
            this.SoundLabel.Text = "Sound:";
            // 
            // EnableSoundsButt
            // 
            this.EnableSoundsButt.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.EnableSoundsButt.Font = new System.Drawing.Font("Calibri", 12.75F);
            this.EnableSoundsButt.ForeColor = System.Drawing.Color.Red;
            this.EnableSoundsButt.Location = new System.Drawing.Point(77, 21);
            this.EnableSoundsButt.Name = "EnableSoundsButt";
            this.EnableSoundsButt.Size = new System.Drawing.Size(152, 38);
            this.EnableSoundsButt.TabIndex = 0;
            this.EnableSoundsButt.Text = "Enable";
            this.EnableSoundsButt.UseVisualStyleBackColor = true;
            this.EnableSoundsButt.Click += new System.EventHandler(this.EnableSoundsButt_Click);
            // 
            // SoundsSettingsPanel
            // 
            this.SoundsSettingsPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(45)))), ((int)(((byte)(45)))), ((int)(((byte)(45)))));
            this.SoundsSettingsPanel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.SoundsSettingsPanel.Controls.Add(this.SoundsSettingsLabel);
            this.SoundsSettingsPanel.Location = new System.Drawing.Point(338, 39);
            this.SoundsSettingsPanel.Name = "SoundsSettingsPanel";
            this.SoundsSettingsPanel.Size = new System.Drawing.Size(308, 28);
            this.SoundsSettingsPanel.TabIndex = 3;
            // 
            // SoundsSettingsLabel
            // 
            this.SoundsSettingsLabel.AutoSize = true;
            this.SoundsSettingsLabel.Font = new System.Drawing.Font("Microsoft JhengHei", 12F);
            this.SoundsSettingsLabel.Location = new System.Drawing.Point(5, 3);
            this.SoundsSettingsLabel.Name = "SoundsSettingsLabel";
            this.SoundsSettingsLabel.Size = new System.Drawing.Size(181, 20);
            this.SoundsSettingsLabel.TabIndex = 4;
            this.SoundsSettingsLabel.Text = "Click Sounds - Settings";
            // 
            // ACSettingsPanel
            // 
            this.ACSettingsPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(45)))), ((int)(((byte)(45)))), ((int)(((byte)(45)))));
            this.ACSettingsPanel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.ACSettingsPanel.Controls.Add(this.ACSettingsLabel);
            this.ACSettingsPanel.Location = new System.Drawing.Point(11, 39);
            this.ACSettingsPanel.Name = "ACSettingsPanel";
            this.ACSettingsPanel.Size = new System.Drawing.Size(320, 28);
            this.ACSettingsPanel.TabIndex = 2;
            // 
            // ACSettingsLabel
            // 
            this.ACSettingsLabel.AutoSize = true;
            this.ACSettingsLabel.Font = new System.Drawing.Font("Microsoft JhengHei", 12F);
            this.ACSettingsLabel.Location = new System.Drawing.Point(3, 3);
            this.ACSettingsLabel.Name = "ACSettingsLabel";
            this.ACSettingsLabel.Size = new System.Drawing.Size(173, 20);
            this.ACSettingsLabel.TabIndex = 3;
            this.ACSettingsLabel.Text = "AutoClicker - Settings";
            // 
            // AutoClickerPanel
            // 
            this.AutoClickerPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(35)))), ((int)(((byte)(35)))), ((int)(((byte)(35)))));
            this.AutoClickerPanel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.AutoClickerPanel.Controls.Add(this.RightClickCheck);
            this.AutoClickerPanel.Controls.Add(this.DropsCheckBox);
            this.AutoClickerPanel.Controls.Add(this.RandomizedCheckBox);
            this.AutoClickerPanel.Controls.Add(this.BindButton);
            this.AutoClickerPanel.Controls.Add(this.EnableACButt);
            this.AutoClickerPanel.Controls.Add(this.BindList);
            this.AutoClickerPanel.Controls.Add(this.WindowTextBox);
            this.AutoClickerPanel.Controls.Add(this.WindowOnlyCheck);
            this.AutoClickerPanel.Controls.Add(this.MinValueHider);
            this.AutoClickerPanel.Controls.Add(this.MaxValueHider);
            this.AutoClickerPanel.Controls.Add(this.MaximumCPS);
            this.AutoClickerPanel.Controls.Add(this.MaxCPS);
            this.AutoClickerPanel.Controls.Add(this.MaxCPSLabel);
            this.AutoClickerPanel.Controls.Add(this.MinCPS);
            this.AutoClickerPanel.Controls.Add(this.MinimumCPS);
            this.AutoClickerPanel.Controls.Add(this.MinCPSLabel);
            this.AutoClickerPanel.Location = new System.Drawing.Point(11, 68);
            this.AutoClickerPanel.Name = "AutoClickerPanel";
            this.AutoClickerPanel.Size = new System.Drawing.Size(320, 207);
            this.AutoClickerPanel.TabIndex = 1;
            // 
            // DropsCheckBox
            // 
            this.DropsCheckBox.AutoSize = true;
            this.DropsCheckBox.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.DropsCheckBox.Font = new System.Drawing.Font("Microsoft JhengHei Light", 10.25F);
            this.DropsCheckBox.Location = new System.Drawing.Point(145, 123);
            this.DropsCheckBox.Name = "DropsCheckBox";
            this.DropsCheckBox.Size = new System.Drawing.Size(91, 22);
            this.DropsCheckBox.TabIndex = 14;
            this.DropsCheckBox.Text = "CPS Drops";
            this.DropsCheckBox.UseVisualStyleBackColor = true;
            // 
            // RandomizedCheckBox
            // 
            this.RandomizedCheckBox.AutoSize = true;
            this.RandomizedCheckBox.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.RandomizedCheckBox.Font = new System.Drawing.Font("Microsoft JhengHei Light", 10.25F);
            this.RandomizedCheckBox.Location = new System.Drawing.Point(145, 107);
            this.RandomizedCheckBox.Name = "RandomizedCheckBox";
            this.RandomizedCheckBox.Size = new System.Drawing.Size(102, 22);
            this.RandomizedCheckBox.TabIndex = 13;
            this.RandomizedCheckBox.Text = "Randomized";
            this.RandomizedCheckBox.UseVisualStyleBackColor = true;
            // 
            // BindButton
            // 
            this.BindButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BindButton.Font = new System.Drawing.Font("Calibri", 9.75F);
            this.BindButton.Location = new System.Drawing.Point(202, 172);
            this.BindButton.Name = "BindButton";
            this.BindButton.Size = new System.Drawing.Size(105, 25);
            this.BindButton.TabIndex = 12;
            this.BindButton.Text = "Bind";
            this.BindButton.UseVisualStyleBackColor = true;
            this.BindButton.Click += new System.EventHandler(this.BindButton_Click);
            // 
            // EnableACButt
            // 
            this.EnableACButt.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.EnableACButt.Font = new System.Drawing.Font("Calibri", 12.75F);
            this.EnableACButt.ForeColor = System.Drawing.Color.Red;
            this.EnableACButt.Location = new System.Drawing.Point(7, 107);
            this.EnableACButt.Name = "EnableACButt";
            this.EnableACButt.Size = new System.Drawing.Size(132, 36);
            this.EnableACButt.TabIndex = 11;
            this.EnableACButt.Text = "Enable";
            this.EnableACButt.UseVisualStyleBackColor = true;
            this.EnableACButt.Click += new System.EventHandler(this.EnableACButt_Click);
            // 
            // BindList
            // 
            this.BindList.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(35)))), ((int)(((byte)(35)))), ((int)(((byte)(35)))));
            this.BindList.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.BindList.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.BindList.Font = new System.Drawing.Font("Calibri", 10.75F);
            this.BindList.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.BindList.FormattingEnabled = true;
            this.BindList.Items.AddRange(new object[] {
            "A",
            "B",
            "C",
            "D",
            "E",
            "F",
            "G",
            "H",
            "I",
            "K",
            "L",
            "M",
            "N",
            "O",
            "P",
            "Q",
            "R",
            "S",
            "T",
            "U",
            "V",
            "W",
            "X",
            "Y",
            "Z"});
            this.BindList.Location = new System.Drawing.Point(261, 141);
            this.BindList.Name = "BindList";
            this.BindList.Size = new System.Drawing.Size(46, 25);
            this.BindList.TabIndex = 9;
            // 
            // WindowTextBox
            // 
            this.WindowTextBox.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(35)))), ((int)(((byte)(35)))), ((int)(((byte)(35)))));
            this.WindowTextBox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.WindowTextBox.Font = new System.Drawing.Font("Calibri", 10.75F);
            this.WindowTextBox.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.WindowTextBox.Location = new System.Drawing.Point(7, 174);
            this.WindowTextBox.MaxLength = 32;
            this.WindowTextBox.Name = "WindowTextBox";
            this.WindowTextBox.Size = new System.Drawing.Size(188, 25);
            this.WindowTextBox.TabIndex = 8;
            this.WindowTextBox.Text = "Google Chrome";
            this.WindowTextBox.TextChanged += new System.EventHandler(this.WindowTextBox_TextChanged);
            // 
            // WindowOnlyCheck
            // 
            this.WindowOnlyCheck.AutoSize = true;
            this.WindowOnlyCheck.Checked = true;
            this.WindowOnlyCheck.CheckState = System.Windows.Forms.CheckState.Checked;
            this.WindowOnlyCheck.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.WindowOnlyCheck.Font = new System.Drawing.Font("Microsoft JhengHei Light", 10.25F);
            this.WindowOnlyCheck.Location = new System.Drawing.Point(8, 146);
            this.WindowOnlyCheck.Name = "WindowOnlyCheck";
            this.WindowOnlyCheck.Size = new System.Drawing.Size(110, 22);
            this.WindowOnlyCheck.TabIndex = 7;
            this.WindowOnlyCheck.Text = "Window Only";
            this.WindowOnlyCheck.UseVisualStyleBackColor = true;
            this.WindowOnlyCheck.CheckedChanged += new System.EventHandler(this.WindowOnlyCheck_CheckedChanged);
            // 
            // MinValueHider
            // 
            this.MinValueHider.Location = new System.Drawing.Point(277, 48);
            this.MinValueHider.Name = "MinValueHider";
            this.MinValueHider.Size = new System.Drawing.Size(30, 11);
            this.MinValueHider.TabIndex = 6;
            // 
            // MaxValueHider
            // 
            this.MaxValueHider.Location = new System.Drawing.Point(277, 102);
            this.MaxValueHider.Name = "MaxValueHider";
            this.MaxValueHider.Size = new System.Drawing.Size(30, 11);
            this.MaxValueHider.TabIndex = 6;
            // 
            // MaximumCPS
            // 
            this.MaximumCPS.LargeChange = 2;
            this.MaximumCPS.Location = new System.Drawing.Point(7, 85);
            this.MaximumCPS.Maximum = 20;
            this.MaximumCPS.Minimum = 1;
            this.MaximumCPS.Name = "MaximumCPS";
            this.MaximumCPS.Size = new System.Drawing.Size(308, 45);
            this.MaximumCPS.TabIndex = 5;
            this.MaximumCPS.TickStyle = System.Windows.Forms.TickStyle.None;
            this.MaximumCPS.Value = 12;
            // 
            // MaxCPS
            // 
            this.MaxCPS.AutoSize = true;
            this.MaxCPS.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.MaxCPS.Location = new System.Drawing.Point(91, 58);
            this.MaxCPS.Name = "MaxCPS";
            this.MaxCPS.Size = new System.Drawing.Size(27, 23);
            this.MaxCPS.TabIndex = 4;
            this.MaxCPS.Text = "12";
            // 
            // MaxCPSLabel
            // 
            this.MaxCPSLabel.AutoSize = true;
            this.MaxCPSLabel.Location = new System.Drawing.Point(3, 58);
            this.MaxCPSLabel.Name = "MaxCPSLabel";
            this.MaxCPSLabel.Size = new System.Drawing.Size(86, 23);
            this.MaxCPSLabel.TabIndex = 3;
            this.MaxCPSLabel.Text = "Max CPS:";
            // 
            // MinCPS
            // 
            this.MinCPS.AutoSize = true;
            this.MinCPS.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.MinCPS.Location = new System.Drawing.Point(91, 5);
            this.MinCPS.Name = "MinCPS";
            this.MinCPS.Size = new System.Drawing.Size(20, 23);
            this.MinCPS.TabIndex = 2;
            this.MinCPS.Text = "7";
            // 
            // MinimumCPS
            // 
            this.MinimumCPS.AutoSize = false;
            this.MinimumCPS.LargeChange = 2;
            this.MinimumCPS.Location = new System.Drawing.Point(7, 32);
            this.MinimumCPS.Maximum = 20;
            this.MinimumCPS.Minimum = 1;
            this.MinimumCPS.Name = "MinimumCPS";
            this.MinimumCPS.Size = new System.Drawing.Size(308, 23);
            this.MinimumCPS.TabIndex = 1;
            this.MinimumCPS.TickStyle = System.Windows.Forms.TickStyle.None;
            this.MinimumCPS.Value = 7;
            // 
            // MinCPSLabel
            // 
            this.MinCPSLabel.AutoSize = true;
            this.MinCPSLabel.Location = new System.Drawing.Point(3, 5);
            this.MinCPSLabel.Name = "MinCPSLabel";
            this.MinCPSLabel.Size = new System.Drawing.Size(82, 23);
            this.MinCPSLabel.TabIndex = 0;
            this.MinCPSLabel.Text = "Min CPS:";
            // 
            // BarPanel
            // 
            this.BarPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(60)))), ((int)(((byte)(60)))));
            this.BarPanel.Controls.Add(this.MinimizeLabel);
            this.BarPanel.Controls.Add(this.CloseLabel);
            this.BarPanel.Controls.Add(this.CrystalLabel);
            this.BarPanel.Location = new System.Drawing.Point(-8, 0);
            this.BarPanel.Name = "BarPanel";
            this.BarPanel.Size = new System.Drawing.Size(680, 32);
            this.BarPanel.TabIndex = 0;
            this.BarPanel.MouseDown += new System.Windows.Forms.MouseEventHandler(this.BarPanel_MouseDown);
            // 
            // MinimizeLabel
            // 
            this.MinimizeLabel.AutoSize = true;
            this.MinimizeLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 19.25F);
            this.MinimizeLabel.Location = new System.Drawing.Point(607, 2);
            this.MinimizeLabel.Name = "MinimizeLabel";
            this.MinimizeLabel.Size = new System.Drawing.Size(22, 30);
            this.MinimizeLabel.TabIndex = 1;
            this.MinimizeLabel.Text = "-";
            this.MinimizeLabel.Click += new System.EventHandler(this.MinimizeLabel_Click);
            this.MinimizeLabel.MouseEnter += new System.EventHandler(this.MinimizeLabel_MouseEnter);
            this.MinimizeLabel.MouseLeave += new System.EventHandler(this.MinimizeLabel_MouseLeave);
            // 
            // CloseLabel
            // 
            this.CloseLabel.AutoSize = true;
            this.CloseLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 19.25F);
            this.CloseLabel.Location = new System.Drawing.Point(629, 1);
            this.CloseLabel.Name = "CloseLabel";
            this.CloseLabel.Size = new System.Drawing.Size(28, 30);
            this.CloseLabel.TabIndex = 1;
            this.CloseLabel.Text = "×";
            this.CloseLabel.Click += new System.EventHandler(this.CloseLabel_Click);
            this.CloseLabel.MouseEnter += new System.EventHandler(this.CloseLabel_MouseEnter);
            this.CloseLabel.MouseLeave += new System.EventHandler(this.CloseLabel_MouseLeave);
            // 
            // CrystalLabel
            // 
            this.CrystalLabel.AutoSize = true;
            this.CrystalLabel.Font = new System.Drawing.Font("Microsoft JhengHei", 14.25F);
            this.CrystalLabel.Location = new System.Drawing.Point(272, 5);
            this.CrystalLabel.Name = "CrystalLabel";
            this.CrystalLabel.Size = new System.Drawing.Size(137, 24);
            this.CrystalLabel.TabIndex = 0;
            this.CrystalLabel.Text = "Simple Clicker";
            // 
            // ValueHandler
            // 
            this.ValueHandler.Enabled = true;
            this.ValueHandler.Interval = 1;
            this.ValueHandler.Tick += new System.EventHandler(this.ValueHandler_Tick);
            // 
            // BindHandler
            // 
            this.BindHandler.Interval = 250;
            this.BindHandler.Tick += new System.EventHandler(this.BindHandler_Tick);
            // 
            // AutoClicker
            // 
            this.AutoClicker.Interval = 90;
            this.AutoClicker.Tick += new System.EventHandler(this.AutoClicker_Tick);
            // 
            // RightClickCheck
            // 
            this.RightClickCheck.AutoSize = true;
            this.RightClickCheck.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.RightClickCheck.Font = new System.Drawing.Font("Microsoft JhengHei Light", 10.25F);
            this.RightClickCheck.Location = new System.Drawing.Point(145, 141);
            this.RightClickCheck.Name = "RightClickCheck";
            this.RightClickCheck.Size = new System.Drawing.Size(90, 22);
            this.RightClickCheck.TabIndex = 15;
            this.RightClickCheck.Text = "Right-Click";
            this.RightClickCheck.UseVisualStyleBackColor = true;
            // 
            // Main
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 23F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(35)))), ((int)(((byte)(35)))), ((int)(((byte)(35)))));
            this.ClientSize = new System.Drawing.Size(660, 400);
            this.ControlBox = false;
            this.Controls.Add(this.MainPanel);
            this.Font = new System.Drawing.Font("Microsoft JhengHei Light", 13.25F);
            this.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(5);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Main";
            this.ShowIcon = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Load += new System.EventHandler(this.Main_Load);
            this.MainPanel.ResumeLayout(false);
            this.SettsPanel.ResumeLayout(false);
            this.SettsPanel.PerformLayout();
            this.SettingsPanel.ResumeLayout(false);
            this.SettingsPanel.PerformLayout();
            this.SelfDestructPanel.ResumeLayout(false);
            this.SelfDestructPanel.PerformLayout();
            this.DestructSettingsPanel.ResumeLayout(false);
            this.DestructSettingsPanel.PerformLayout();
            this.SoundsPanel.ResumeLayout(false);
            this.SoundsPanel.PerformLayout();
            this.SoundsSettingsPanel.ResumeLayout(false);
            this.SoundsSettingsPanel.PerformLayout();
            this.ACSettingsPanel.ResumeLayout(false);
            this.ACSettingsPanel.PerformLayout();
            this.AutoClickerPanel.ResumeLayout(false);
            this.AutoClickerPanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.MaximumCPS)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.MinimumCPS)).EndInit();
            this.BarPanel.ResumeLayout(false);
            this.BarPanel.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel MainPanel;
        private System.Windows.Forms.Panel BarPanel;
        private System.Windows.Forms.Label CrystalLabel;
        private System.Windows.Forms.Label CloseLabel;
        private System.Windows.Forms.Label MinimizeLabel;
        private System.Windows.Forms.Panel AutoClickerPanel;
        private System.Windows.Forms.Panel ACSettingsPanel;
        private System.Windows.Forms.Label ACSettingsLabel;
        private System.Windows.Forms.Label MinCPSLabel;
        private System.Windows.Forms.TrackBar MinimumCPS;
        private System.Windows.Forms.Panel MaxValueHider;
        private System.Windows.Forms.TrackBar MaximumCPS;
        private System.Windows.Forms.Label MaxCPS;
        private System.Windows.Forms.Label MaxCPSLabel;
        private System.Windows.Forms.Label MinCPS;
        private System.Windows.Forms.Panel MinValueHider;
        private System.Windows.Forms.Timer ValueHandler;
        private System.Windows.Forms.TextBox WindowTextBox;
        private System.Windows.Forms.CheckBox WindowOnlyCheck;
        private System.Windows.Forms.ComboBox BindList;
        private System.Windows.Forms.Button EnableACButt;
        private System.Windows.Forms.Button BindButton;
        private System.Windows.Forms.Timer BindHandler;
        private System.Windows.Forms.Timer AutoClicker;
        private System.Windows.Forms.CheckBox DropsCheckBox;
        private System.Windows.Forms.CheckBox RandomizedCheckBox;
        private System.Windows.Forms.Panel SoundsSettingsPanel;
        private System.Windows.Forms.Panel SoundsPanel;
        private System.Windows.Forms.Label SoundsSettingsLabel;
        private System.Windows.Forms.Button EnableSoundsButt;
        private System.Windows.Forms.ComboBox SoundsList;
        private System.Windows.Forms.Label SoundLabel;
        private System.Windows.Forms.Panel SettsPanel;
        private System.Windows.Forms.Panel SettingsPanel;
        private System.Windows.Forms.Label SettingsLabel;
        private System.Windows.Forms.Panel SelfDestructPanel;
        private System.Windows.Forms.CheckBox DisableHWIDCheck;
        private System.Windows.Forms.CheckBox MemoryCheck;
        private System.Windows.Forms.CheckBox AppDataPrefetchCheck;
        private System.Windows.Forms.CheckBox DeleteFilesCheck;
        private System.Windows.Forms.Button DestructButt;
        private System.Windows.Forms.Panel DestructSettingsPanel;
        private System.Windows.Forms.Label DestructSettingsLabel;
        private System.Windows.Forms.CheckBox LoadOnStartCheck;
        private System.Windows.Forms.Button LoadSettsButt;
        private System.Windows.Forms.Button SaveSettsButt;
        private System.Windows.Forms.CheckBox RightClickCheck;
    }
}

