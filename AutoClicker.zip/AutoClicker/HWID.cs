﻿using System;
using Microsoft.Win32;
using System.Collections.Generic;

namespace AutoClicker.Main
{
    internal class HWID
    {
        public static string GetMachineGuid()
        {
            var location = @"SOFTWARE\Microsoft\Cryptography";
            var name = "MachineGuid";

            using (RegistryKey localMachineX64View = RegistryKey.OpenBaseKey(RegistryHive.LocalMachine, RegistryView.Registry64))
            {
                using (RegistryKey rk = localMachineX64View.OpenSubKey(location))
                {
                    if (rk == null)
                        throw new KeyNotFoundException(string.Format("Key Not Found: {0}", location));
                    var machineGuid = rk.GetValue(name);
                    if (machineGuid == null)
                        throw new IndexOutOfRangeException(string.Format("Index Not Found: {0}", name));
                    return machineGuid.ToString();
                }
            }
        }
    }
}
